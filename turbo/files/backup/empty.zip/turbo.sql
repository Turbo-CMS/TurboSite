/* Data for table t_articles */
TRUNCATE TABLE `t_articles`;

/* Data for table t_articles_categories */
TRUNCATE TABLE `t_articles_categories`;

/* Data for table t_banners */
TRUNCATE TABLE `t_banners`;
INSERT INTO `t_banners` (`id`, `group_id`, `name`, `position`, `visible`, `show_all_pages`, `pages`, `projects_categories`, `articles_categories`) VALUES
('1','1','Main slider','1','1','0','1','0','0');

/* Data for table t_banners_images */
TRUNCATE TABLE `t_banners_images`;
INSERT INTO `t_banners_images` (`id`, `banner_id`, `name`, `alt`, `title`, `description`, `url`, `color`, `style`, `code`, `button`, `image`, `background`, `position`, `visible`) VALUES
('1','1','TurboSite Solutions','TurboSite Solutions For Your Business','TurboSite Solutions For Your Business','For Your Business','/','','','','Get Started','hero-slide01.png','','1','1'),
('2','1','Easy Marketing Solutions','Easy Marketing Solutions For Your Business','Easy Marketing Solutions For Your Business','For Your Business','/','','','','Get Started','hero-slide02.png','','2','1'),
('3','1','We Provide Solutions','We provide solutions for your business','We provide solutions for your business','For Your Business','/','','','','Get Started','hero-slide03.png','','3','1');

/* Data for table t_blog */
TRUNCATE TABLE `t_blog`;

/* Data for table t_callbacks */
TRUNCATE TABLE `t_callbacks`;

/* Data for table t_comments */
TRUNCATE TABLE `t_comments`;

/* Data for table t_faq */
TRUNCATE TABLE `t_faq`;

/* Data for table t_feedbacks */
TRUNCATE TABLE `t_feedbacks`;

/* Data for table t_files */
TRUNCATE TABLE `t_files`;

/* Data for table t_images_project */
TRUNCATE TABLE `t_images_project`;

/* Data for table t_lang_articles */
TRUNCATE TABLE `t_lang_articles`;

/* Data for table t_lang_articles_categories */
TRUNCATE TABLE `t_lang_articles_categories`;

/* Data for table t_lang_banners_images */
TRUNCATE TABLE `t_lang_banners_images`;
INSERT INTO `t_lang_banners_images` (`lang_id`, `lang_label`, `banner_image_id`, `name`, `alt`, `title`, `description`, `url`, `button`) VALUES
('1','','1','Решения TurboSite','Решения TurboSite для вашего бизнеса','Решения TurboSite для вашего бизнеса','Для вашего бизнеса','/','Начать'),
('2','','1','TurboSite Solutions','TurboSite Solutions For Your Business','TurboSite Solutions For Your Business','For Your Business','/','Get Started'),
('3','','1','Рішення TurboSite ','Рішення TurboSite для вашого бізнесу','Рішення TurboSite для вашого бізнесу','Для вашого бізнесу','/','Розпочати'),
('1','','2','Простые маркетинговые решения','Простые маркетинговые решения для вашего бизнеса','Простые маркетинговые решения для вашего бизнеса','Для вашего бизнеса','/','Начать'),
('2','','2','Easy Marketing Solutions','Easy Marketing Solutions For Your Business','Easy Marketing Solutions For Your Business','For Your Business','/','Get Started'),
('3','','2','Прості маркетингові рішення','Прості маркетингові рішення для вашого бізнесу','Прості маркетингові рішення для вашого бізнесу','Для вашого бізнесу','/','Розпочати'),
('1','','3','Мы предоставляем решения','Мы предоставляем решения для вашего бизнеса','Мы предоставляем решения для вашего бизнеса','Для вашего бизнеса','/','Начать'),
('2','','3','We Provide Solutions','We provide solutions for your business','We provide solutions for your business','For Your Business','/','Get Started'),
('3','','3','Ми надаємо рішення','Ми надаємо рішення для вашого бізнесу','Ми надаємо рішення для вашого бізнесу','Для вашого бізнесу','/','Розпочати');

/* Data for table t_lang_blog */
TRUNCATE TABLE `t_lang_blog`;

/* Data for table t_lang_faq */
TRUNCATE TABLE `t_lang_faq`;

/* Data for table t_lang_files */
TRUNCATE TABLE `t_lang_files`;

/* Data for table t_lang_pages */
TRUNCATE TABLE `t_lang_pages`;
INSERT INTO `t_lang_pages` (`lang_id`, `lang_label`, `page_id`, `name`, `meta_title`, `meta_description`, `meta_keywords`, `body`, `header`) VALUES
('1','','1','Turbo Site','Turbo Site','Turbo Site - это готовое решение, которое позволит вам создать свой мультиязычный, простой и адаптивный сайт на  TurboCMS  за 24 часа.','Turbo Site','<p>Turbo Site - это готовое решение, которое позволит вам создать свой мультиязычный, простой и адаптивный сайт на TurboCMS за 24 часа. Данное решение не содержит ничего лишнего, но при этом тщательно проработано до мелочей. Готовый сайт-визитка отлично подойдет для компаний, которые предоставляют услуги в различных сегментах.&nbsp;</p>','Главная'),
('2','','1','Turbo Site','Turbo Site','Turbo Site is a turnkey solution that will allow you to create your multilingual, simple and responsive site on  TurboCMS  in 24 hours. ','Turbo Site','<p>Turbo Site is a turnkey solution that will allow you to create your multilingual, simple and responsive site on TurboCMS in 24 hours. This solution does not contain anything superfluous, but at the same time it is carefully worked out to the smallest detail. A ready-made business card site is perfect for companies that provide services in various segments.</p>','Home'),
('3','','1','Turbo Site','Turbo Site','Turbo Site - це готове рішення, яке дозволить вам створити свій багатомовний, простий і адаптивний сайт на Turbo CMS  за 24 години. ','Turbo Site','<p>Turbo Site - це готове рішення, яке дозволить вам створити свій багатомовний, простий і адаптивний сайт на TurboCMS за 24 години. Дане рішення не містить нічого зайвого, але при цьому ретельно опрацьовано до дрібниць. Готовий сайт-візитка відмінно підійде для компаній, які надають послуги в різних сегментах.</p>','Головна'),
('1','','3','404','Страница не найдена','Страница не найдена','Страница не найдена','<p>Страница не найдена</p>','Страница не найдена'),
('2','','3','404','Page not found','Page not found','Page not found','<p>Page not found</p>','Page not found'),
('3','','3','404','Сторінка не знайдена','Сторінка не знайдена','Сторінка не знайдена','<p>Сторінка не знайдена</p>','Сторінка не знайдена'),
('1','','4','Карта сайта','Карта сайта','Карта сайта','Карта сайта','','Карта сайта'),
('2','','4','Sitemap','Sitemap','Sitemap','Sitemap','','Sitemap'),
('3','','4','Карта сайту','Карта сайту','Карта сайту','Карта сайту','','Карта сайту'),
('1','','13','Блог','Блог','','Блог','','Блог'),
('2','','13','Blog','Blog','','Blog','','Blog'),
('3','','13','Блог','Блог','','Блог','','Блог'),
('1','','14','Контакты','Контакты','Контакты','Контакты','<p><span class=\"JLqJ4b ChMk0b\" data-language-for-alternatives=\"ru\" data-language-to-translate-into=\"uk\" data-phrase-index=\"0\" data-number-of-phrases=\"2\"><span class=\"Q4iAWc\">Киев, ул.</span></span> <span class=\"JLqJ4b ChMk0b\" data-language-for-alternatives=\"ru\" data-language-to-translate-into=\"uk\" data-phrase-index=\"1\" data-number-of-phrases=\"2\"><span class=\"Q4iAWc\">Глубочицкая, </span></span>32б, 02000</p>\r\n<p>Телефон: (095) 545-54-54</p>\r\n<p><iframe style=\"border: 0;\" tabindex=\"0\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1269.9307677918514!2d30.49195294945491!3d50.46230305803582!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x84a28f327eb7dc52!2z0JDRgNC10L3QtNCwINC-0YTQuNGB!5e0!3m2!1sru!2sua!4v1609513285692!5m2!1sru!2sua\" width=\"100%\" height=\"450\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\" aria-hidden=\"false\"></iframe></p>','Контакты'),
('2','','14','Contacts','Contacts','Contacts','Contacts','<p>41 West 40th Street New York, NY</p>\r\n<p>Phone: (210) 876-5432</p>\r\n<p><iframe style=\"border: 0;\" tabindex=\"0\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4399.518506840664!2d-73.97964170435294!3d40.75394620817656!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259aa94a61b4f%3A0x8ebce7fe1262c134!2zNDEgVyA0MHRoIFN0LCBOZXcgWW9yaywgTlkgMTAwMTgsINCh0KjQkA!5e0!3m2!1sru!2sua!4v1609512981791!5m2!1sru!2sua\" width=\"100%\" height=\"450\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\" aria-hidden=\"false\"></iframe></p>','Contacts'),
('3','','14','Контакти','Контакти','Контакти','Контакти','<p>Київ, вул. Глибочицька, 32б, 02000</p>\r\n<p>Телефон: (095) 545-54-54</p>\r\n<p><iframe style=\"border: 0;\" tabindex=\"0\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1269.9307677918514!2d30.49195294945491!3d50.46230305803582!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x84a28f327eb7dc52!2z0JDRgNC10L3QtNCwINC-0YTQuNGB!5e0!3m2!1sru!2sua!4v1609513285692!5m2!1sru!2sua\" width=\"100%\" height=\"450\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\" aria-hidden=\"false\"></iframe></p>','Контакти'),
('1','','16','Статьи','Статьи','','Статьи','','Статьи'),
('2','','16','Articles','Articles','','Articles','','Articles'),
('3','','16','Статті','Статті','','Статті','','Статті'),
('1','','18','Поиск','Поиск','','Поиск','','Поиск'),
('2','','18','Search','Search','','Search','','Search'),
('3','','18','Пошук','Пошук','','Пошук','','Пошук'),
('2','','27','Projects','Projects','','Projects','','Projects'),
('3','','27','Проекти','Проекти','','Проекти','','Проекти'),
('1','','27','Проекты','Проекты','','Проекты','','Проекты'),
('1','','25','FAQ','FAQ','FAQ','FAQ','','FAQ'),
('2','','25','FAQ','FAQ','FAQ','FAQ','','FAQ'),
('3','','25','FAQ','FAQ','FAQ','FAQ','','FAQ'),
('1','','26','Отзывы','Отзывы','Отзывы','Отзывы','','Отзывы'),
('2','','26','Reviews','Reviews','Reviews','Reviews','','Reviews'),
('3','','26','Відгуки','Відгуки','Відгуки','Відгуки','','Відгуки');

/* Data for table t_lang_projects */
TRUNCATE TABLE `t_lang_projects`;

/* Data for table t_lang_projects_categories */
TRUNCATE TABLE `t_lang_projects_categories`;

/* Data for table t_languages */
TRUNCATE TABLE `t_languages`;
INSERT INTO `t_languages` (`id`, `name`, `label`, `enabled`, `position`) VALUES
('1','Russian','ru','1','3'),
('2','English','en','1','1'),
('3','Ukrainian','ua','1','2');

/* Data for table t_menu */
TRUNCATE TABLE `t_menu`;
INSERT INTO `t_menu` (`id`, `name`, `position`) VALUES
('1','Main menu','1'),
('2','Other pages','2'),
('3','Information','3');

/* Data for table t_pages */
TRUNCATE TABLE `t_pages`;
INSERT INTO `t_pages` (`id`, `parent_id`, `url`, `name`, `meta_title`, `meta_description`, `meta_keywords`, `body`, `menu_id`, `position`, `visible`, `header`, `last_modified`) VALUES
('1','0','','Turbo Site','Turbo Site','Turbo Site is a turnkey solution that will allow you to create your multilingual, simple and responsive site on  TurboCMS  in 24 hours. ','Turbo Site','<p>Turbo Site is a turnkey solution that will allow you to create your multilingual, simple and responsive site on TurboCMS in 24 hours. This solution does not contain anything superfluous, but at the same time it is carefully worked out to the smallest detail. A ready-made business card site is perfect for companies that provide services in various segments.</p>','1','1','1','Home','2022-08-31 23:49:15'),
('3','0','404','404','Page not found','Page not found','Page not found','<p>Page not found</p>','2','3','1','Page not found','2022-08-26 02:25:06'),
('4','0','sitemap','Sitemap','Sitemap','Sitemap','Sitemap','','2','27','1','Sitemap','2022-08-31 23:56:33'),
('13','0','blog','Blog','Blog','','Blog','','1','25','1','Blog','2022-08-31 23:49:15'),
('14','0','contact','Contacts','Contacts','Contacts','Contacts','<p>41 West 40th Street New York, NY</p>\r\n<p>Phone: (210) 876-5432</p>\r\n<p><iframe style=\"border: 0;\" tabindex=\"0\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4399.518506840664!2d-73.97964170435294!3d40.75394620817656!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259aa94a61b4f%3A0x8ebce7fe1262c134!2zNDEgVyA0MHRoIFN0LCBOZXcgWW9yaywgTlkgMTAwMTgsINCh0KjQkA!5e0!3m2!1sru!2sua!4v1609512981791!5m2!1sru!2sua\" width=\"100%\" height=\"450\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\" aria-hidden=\"false\"></iframe></p>','1','26','1','Contacts','2022-08-31 23:49:15'),
('16','0','articles','Articles','Articles','','Articles','','3','14','1','Articles','2022-08-31 23:55:55'),
('18','0','search','Search','Search','','Search','','3','17','1','Search','2022-08-31 23:55:55'),
('27','0','projects','Projects','Projects','','Projects','','3','16','1','Projects','2023-11-16 22:50:10'),
('25','0','faq','FAQ','FAQ','FAQ','FAQ','','3','18','1','FAQ','2023-11-16 21:37:37'),
('26','0','reviews','Reviews','Reviews','Reviews','Reviews','','1','15','1','Reviews','2022-08-31 23:49:15');

/* Data for table t_projects */
TRUNCATE TABLE `t_projects`;

/* Data for table t_projects_categories */
TRUNCATE TABLE `t_projects_categories`;

/* Data for table t_related_projects */
TRUNCATE TABLE `t_related_projects`;

/* Data for table t_seo */
TRUNCATE TABLE `t_seo`;
INSERT INTO `t_seo` (`setting_id`, `name`, `value`) VALUES
('1','am_url','www.example.com'),
('2','am_name','Turbo Site'),
('3','am_phone','(123) 456-78-90'),
('4','am_email','me@example.com'),
('5','category_meta_title',''),
('6','category_brand_meta_title',''),
('7','brand_meta_title',''),
('8','product_meta_title',''),
('9','page_meta_title',''),
('10','post_meta_title',''),
('11','category_article_meta_title',''),
('12','article_meta_title',''),
('13','category_meta_keywords',''),
('14','category_brand_meta_keywords',''),
('15','brand_meta_keywords',''),
('16','product_meta_keywords',''),
('17','page_meta_keywords',''),
('18','post_meta_keywords',''),
('19','category_article_meta_keywords',''),
('20','article_meta_keywords',''),
('21','category_meta_description',''),
('22','category_brand_meta_description',''),
('23','brand_meta_description',''),
('24','product_meta_description',''),
('25','page_meta_description',''),
('26','post_meta_description',''),
('27','category_article_meta_description',''),
('28','article_meta_description',''),
('29','seo_automation','on');

/* Data for table t_seo_lang */
TRUNCATE TABLE `t_seo_lang`;
INSERT INTO `t_seo_lang` (`name`, `lang_id`, `value`) VALUES
('am_email','1','me@example.com'),
('am_name','1','Turbo Site'),
('am_phone','1','(123) 456-78-90'),
('am_url','1','www.example.com'),
('article_meta_description','1',''),
('article_meta_keywords','1',''),
('article_meta_title','1',''),
('brand_meta_description','1',''),
('brand_meta_keywords','1',''),
('brand_meta_title','1',''),
('category_article_meta_description','1',''),
('category_article_meta_keywords','1',''),
('category_article_meta_title','1',''),
('category_brand_meta_description','1',''),
('category_brand_meta_keywords','1',''),
('category_brand_meta_title','1',''),
('category_meta_description','1',''),
('category_meta_keywords','1',''),
('category_meta_title','1',''),
('page_meta_description','1',''),
('page_meta_keywords','1',''),
('page_meta_title','1',''),
('post_meta_description','1',''),
('post_meta_keywords','1',''),
('post_meta_title','1',''),
('product_meta_description','1',''),
('product_meta_keywords','1',''),
('product_meta_title','1',''),
('am_email','2','me@example.com'),
('am_name','2','Turbo Site'),
('am_phone','2','(123) 456-78-90'),
('am_url','2','www.example.com'),
('article_meta_description','2',''),
('article_meta_keywords','2',''),
('article_meta_title','2',''),
('brand_meta_description','2',''),
('brand_meta_keywords','2',''),
('brand_meta_title','2',''),
('category_article_meta_description','2',''),
('category_article_meta_keywords','2',''),
('category_article_meta_title','2',''),
('category_brand_meta_description','2',''),
('category_brand_meta_keywords','2',''),
('category_brand_meta_title','2',''),
('category_meta_description','2',''),
('category_meta_keywords','2',''),
('category_meta_title','2',''),
('page_meta_description','2',''),
('page_meta_keywords','2',''),
('page_meta_title','2',''),
('post_meta_description','2',''),
('post_meta_keywords','2',''),
('post_meta_title','2',''),
('product_meta_description','2',''),
('product_meta_keywords','2',''),
('product_meta_title','2',''),
('am_email','3','me@example.com'),
('am_name','3','Turbo Site'),
('am_phone','3','(123) 456-78-90'),
('am_url','3','www.example.com'),
('article_meta_description','3',''),
('article_meta_keywords','3',''),
('article_meta_title','3',''),
('brand_meta_description','3',''),
('brand_meta_keywords','3',''),
('brand_meta_title','3',''),
('category_article_meta_description','3',''),
('category_article_meta_keywords','3',''),
('category_article_meta_title','3',''),
('category_brand_meta_description','3',''),
('category_brand_meta_keywords','3',''),
('category_brand_meta_title','3',''),
('category_meta_description','3',''),
('category_meta_keywords','3',''),
('category_meta_title','3',''),
('page_meta_description','3',''),
('page_meta_keywords','3',''),
('page_meta_title','3',''),
('post_meta_description','3',''),
('post_meta_keywords','3',''),
('post_meta_title','3',''),
('product_meta_description','3',''),
('product_meta_keywords','3',''),
('product_meta_title','3','');

/* Data for table t_settings */
TRUNCATE TABLE `t_settings`;
INSERT INTO `t_settings` (`setting_id`, `name`, `value`) VALUES
('1','theme','default'),
('2','date_format','d.m.Y'),
('3','admin_email','me@example.com'),
('4','site_work','on'),
('78','category_count','0'),
('77','captcha_callback',''),
('76','captcha_feedback',''),
('75','captcha_register',''),
('74','captcha_article',''),
('14','comment_email','me@example.com'),
('15','notify_from_email','me@example.com'),
('16','email_lang','en'),
('22','lang','en'),
('23','articles_num','15'),
('24','articles_num_admin','15'),
('25','blog_num','15'),
('26','blog_num_admin','15'),
('27','smart_resize',''),
('28','webp_support','1'),
('30','watermark_offset_x','50'),
('31','watermark_offset_y','50'),
('32','watermark_transparency','50'),
('33','images_sharpen','50'),
('42','image_sizes','55x55|110x110|90x90|240x240|570x570|800x800w|300x300|95x95|330x300|500x500|100x100|900x350|35x35|400x300|300x120|130x130|150x150|170x170|116x116|75x23|40x40|700x700|750x750|750x300|750x467|700x467|250x120|50x50|700x300|120x120|700x400|800x800|750x500|800x600|500x300|400x400|966x378|45x45|90x60|800x285|170x100|180x100|550x440|200x100|800x400|1000x1000w'),
('43','comments_tree_blog','on'),
('44','comments_tree_articles','on'),
('45','lastModifyPosts','2023-11-18 22:38:02'),
('46','projects_num','15'),
('47','projects_num_admin','15'),
('48','captcha_project',''),
('50','chat_viber','123456789'),
('51','chat_whats_app','123456789'),
('52','chat_telegram','usename'),
('53','chat_facebook','usename'),
('54','captcha_review',''),
('55','comments_tree_projects','on'),
('57','lastModifyReviews','2022-08-29 01:23:49'),
('58','comments_tree_reviews','on'),
('59','lastModifyFAQ','2022-08-29 00:55:00'),
('60','cached','0'),
('61','cache_type','0'),
('62','cache_time','86400'),
('63','counters','a:0:{}'),
('64','watermark_enable','1'),
('65','admin_theme','default'),
('66','sidebar','default'),
('67','layout','fluid'),
('68','position','left'),
('69','captcha_cart',''),
('70','comments_num','15'),
('71','comments_num_admin','15'),
('73','captcha_post','');

/* Data for table t_settings_lang */
TRUNCATE TABLE `t_settings_lang`;
INSERT INTO `t_settings_lang` (`name`, `lang_id`, `value`) VALUES
('company_name','1','Turbo CMS'),
('notify_from_name','1','Admin'),
('site_name','1','Turbo Site'),
('company_name','2','Turbo CMS'),
('notify_from_name','2','Admin'),
('site_name','2','Turbo Site'),
('company_name','3','Turbo CMS'),
('notify_from_name','3','Адмін'),
('site_name','3','Turbo Site');

/* Data for table t_subscribes */
TRUNCATE TABLE `t_subscribes`;

/* Data for table t_theme_settings */
TRUNCATE TABLE `t_theme_settings`;
INSERT INTO `t_theme_settings` (`setting_id`, `name`, `value`) VALUES
('1','header_type','1'),
('3','footer_type','1');

/* Data for table t_translations */
TRUNCATE TABLE `t_translations`;
INSERT INTO `t_translations` (`id`, `label`, `lang_ru`, `lang_en`, `lang_ua`) VALUES
('39','callback','Заказать звонок','Request a call','Замовити дзвінок'),
('40','contact_details','Киев, ул. Глубочицкая, 32б','41 West 40th Street New York, NY','Київ, вул. Глибочицька, 32б'),
('6','bloge','Блоге','entries','Блогу'),
('41','phone_number','(903) 782-82-82','(210) 876-5432','(095) 545-54-54'),
('42','close','Закрыть','Close','Закрити'),
('43','catalog','Каталог','Catalog','Каталог'),
('9','aktsionnye_tovary','Акционные товары','Action goods','Акційні товари'),
('37','login','Вход','Login','Вхід'),
('22','votes','голосов','votes','голосів'),
('21','vote','голос','vote','голос'),
('38','logout','Выйти','Logout','Вихід'),
('18','more_details','Далее','More details','Далі'),
('20','In_stock','В наличии','In stock','В наявності'),
('23','of_vote','голоса','vote','голоси'),
('28','delete','Удалить','Delete','Видалити'),
('34','sale','Акционные товары','Sale','Акційні товари'),
('36','registration','Регистрация','Registration','Реєстрація'),
('50','enter_your_email','Оставьте свой e-mail','Enter your Email','Залиште свій e-mail'),
('51','main_description','Этот сайт является демонстрацией скрипта Turbo CMS. Все материалы на этом сайте присутствуют исключительно в демонстрационных целях.','This website is a demo of the script of the Turbo CMS. All materials on this site are present for demonstration purposes only.','Цей сайт є демонстрацією скрипта Turbo CMS. Всі матеріали на цьому сайті присутні виключно в демонстраційних цілях.'),
('54','information','Информация','Information','Інформація'),
('55','contacts','Контакты','Contacts','Контакти'),
('56','request_a_call','Заказать звонок','Request a call','Замовити дзвінок'),
('57','your_phone_number','Оставьте свой номер телефона','Leave your phone number','Залиште свій номер телефону'),
('58','enter_your_name','Введите имя','Enter your name','Введіть ім\'я'),
('59','enter_phone_number','Введите номер телефона','Enter your phone number','Введіть номер телефону'),
('60','captcha_incorrect','Неверно введена капча','Captcha entered incorrectly','Невірно введена капча'),
('61','enter_the_address','Введите адрес','Enter the address','Введіть адресу'),
('62','enter_captcha','Введите капчу','Enter captcha','Введіть капчу'),
('63','name','Имя','Name','Ім\'я'),
('64','enter_a_comment','Введите комментарий','Enter a comment','Введіть коментар'),
('66','home','Главная','Home','Головна'),
('67','password','Пароль','Password','Пароль'),
('68','forgot_password','Забыли пароль?','Forgot your password','Забули пароль?'),
('69','enter_password','Введите пароль','Enter password','Введіть пароль'),
('70','phone','Телефон','Phone','Телефон'),
('71','address','Адрес','Address','Адреса'),
('72','email_already_registered','Пользователь с таким email уже зарегистрирован','User with this email is already registered','Користувач з таким email вже зареєстрований'),
('73','send','Отправить','Send','Надіслати'),
('74','short_description','Краткое описание','Short description','Короткий опис'),
('78','sku','Артикул','SKU','Артикул'),
('81','description','Описание','Description','Опис'),
('83','comments_global','Комментарии','Comments','Коментарі'),
('84','awaiting_moderation','ожидает модерации','awaiting moderation','очікує модерації'),
('85','comment_1','Комментарий','Comment','Коментар'),
('86','comment_on','Комментировать','Comment on','Коментувати'),
('87','no_comments','Пока нет комментариев','No comments','Поки немає коментарів'),
('111','reply','Ответить','Reply','Відповісти'),
('96','files_global','Файлы','Files','Файли'),
('97','videos_global','Видео','Video','Відео'),
('99','sort_by','Сортировать по','Sort by','Сортувати за'),
('100','default','Умолчанию','Default','Замовчуванням'),
('101','name_a_z','По имени от А до Я','By name from A to Z','На ім\'я від А до Я'),
('102','name_z_a','По имени от Я до А','By name from Z to A','На ім\'я від Я до А'),
('105','by_rating','По рейтингу','By rating','за рейтингом'),
('107','search','Поиск','Search','Пошук'),
('108','nothing_found','Ничего не найдено','Nothing found','Нічого не знайдено'),
('109','enter_search_query','Введите поисковый запрос','Enter your search term','Введіть пошуковий запит'),
('110','site_search','Поиск по сайту','Site search','Пошук по сайту'),
('112','at','в','at','в'),
('114','in_order','По порядку','In order','По порядку'),
('115','comment_2','Комментариев','Comments','Коментарів'),
('116','table_of_contents','Содержание','Table of Contents','Зміст'),
('117','already_voted','Вы уже голосовали!','You have already voted!','Ви вже голосували!'),
('118','vote_counted','Спасибо! Ваш голос учтен.','Thank you! Your vote has been counted.','Спасибі! Ваш голос враховано.'),
('119','message_sent','Сообщение отправлено','Message sent','Повідомлення відправлено'),
('120','success_subscribe','Вы были успешно подписаны','You have been successfully subscribed','Ви були успішно підписані'),
('121','already_subscribe','Вы уже подписаны','You are already subscribed','Ви вже підписані'),
('122','subscribe_to','Подписаться','Subscribe to','Підписатися'),
('123','search_article','Поиск статьи...','Search article...','Пошук статті...'),
('124','sitemap','Карта сайта','Sitemap','Карта сайту'),
('127','sort_date','По дате','Date','За датою'),
('128','search_blog','Поиск в блоге...','Search blog...','Пошук в блозі...'),
('130','apply','Применить','Apply','Застосувати'),
('131','reset','Сбросить','Reset','Скинути'),
('133','index_feedback','Обратная связь','Feedback','Зворотній зв\'язок'),
('134','feedback_message_sent','ваше сообщение отправлено.','your message has been sent.','ваше повідомлення відправлено.'),
('135','enter_your_message','Введите сообщение','Enter your message','Введіть повідомлення'),
('136','message','Сообщение','Message','Повідомлення'),
('137','password_reminder','Напоминание пароля','Password reminder','Нагадування пароля'),
('138','email_sent','Вам отправлено письмо','An email has been sent to you','Вам надіслано листа'),
('139','user_not_found','Пользователь не найден','User is not found','Користувач не знайдений'),
('140','password_recovery_email','отправлено письмо для восстановления пароля.','password recovery email has been sent.','відправлено лист для відновлення пароля.'),
('141','enter_email_registration','Введите email, который вы указывали при регистрации','Enter the email you provided during registration','Введіть email, який ви вказали при реєстрації'),
('142','wrong_login_password','Неверный логин или пароль','Wrong login or password','Невірний логін або пароль'),
('143','not_activated','Ваш аккаунт еще не активирован.','Your account has not been activated yet.','Ваш аккаунт ще не був активований.'),
('144','no_post_found','Записи не найдены','No post found','Публікації не знайдено'),
('251','popular','Популярные','Popular','Популярні'),
('146','change_password','Изменить пароль','Change Password','Змінити пароль'),
('147','save','Сохранить','Save','Зберегти'),
('151','waiting_processing','ждет обработки','waiting for processing','чекає обробки'),
('152','in_processing','в обработке','in processing','в обробці'),
('153','completed','выполнен','completed','виконаний'),
('154','site_closed','Сайт закрыт на техническое обслуживание','Site closed for maintenance','Сайт зараз закритий на технічне обслуговування'),
('155','apologize','Приносим извинения за неудобство, но в данный момент сайт находится на техническом обслуживание. Скоро мы вернемся online!','We apologize for the inconvenience, but the site is currently undergoing maintenance. We\'ll be back online soon!','Приносимо вибачення за незручність, але в даний момент сайт знаходиться на технічному обслуговуванні. Скоро ми повернемося online!'),
('156','forward','вперед','forward','вперед'),
('157','back','назад','back','назад'),
('158','all_at_once','все сразу','all at once','всі відразу'),
('160','accepted','принят','accepted','прийнятий'),
('161','general_name','Название','Name','Назва'),
('163','number','Количество','Number','Кількість'),
('166','coupon','Купон','Coupon','Купон'),
('177','proceed_to_checkout','Перейти к оплате','Proceed to checkout','Перейти до оплати'),
('186','address_recipient','Адрес получателя','Address of the recipient','Адреса отримувача'),
('187','general_full_name','ФИО','Full name','ПІБ'),
('190','new_password','Новый пароль','New password','Новий пароль'),
('191','on_the_site','на сайте','on the site','на сайті'),
('192','email_password_reply','был сделан запрос на восстановление вашего пароля.','a request was made to recover your password.','був зроблений запит на відновлення вашого пароля.'),
('193','email_password_change','Вы можете изменить пароль, перейдя по следующей ссылке','You can change your password by following the link below','Ви можете змінити пароль, перейшовши за наступним посиланням'),
('194','email_password_text','Эта ссылка действует в течение нескольких минут. <br> Если это письмо пришло вам по ошибке, проигнорируйте его.','This link is effective for a few minutes. <br> If you received this error in error, ignore it.','Це посилання діє протягом декількох хвилин. <br>  Якщо цей лист прийшло вам помилково, ігноруйте його.'),
('197','canceled','отменен','canceled','скасований'),
('200','status','Статус','Status','Статус'),
('202','compare','Сравнение','Compare','Порівняння'),
('205','no_articles_found','Статьи не найдены','No articles found','Статті не знайдені'),
('211','see_all','Посмотреть все','See all','Переглянути всі'),
('212','captcha','Капча','Captcha','Капча'),
('215','weight','Вес','Weight','Вага'),
('217','email_comment_hello','Здравствуйте,','Hello,','Вітаємо,'),
('219','email_from','от','of','від'),
('224','password_remind_title','Восстановление пароля','Password recovery','Відновлення пароля'),
('227','contact_us','Связаться с нами','To contact us','Зв\'язатися з нами'),
('230','reviews_global','Отзывы','Reviews','Відгуки'),
('231','voice','голос','voice','голос'),
('232','comment_3','Комментария','Comment','Коментаря'),
('233','heading','Рубрика','Heading','Рубрика'),
('234','comment','Комментарий','Comment','Коментар'),
('236','general_all','Все','All','Всі'),
('237','next','Вперёд','Next','Вперед'),
('238','previous','Назад','Prev','Назад'),
('239','features_support','Поддержка 24/7','24/7 support','Підтримка 24/7 '),
('240','message_support','Здесь вы можете написать анонс к оказываемой услуге при желании.','Here you can write an announcement to the service provided if you wish.','Тут ви можете написати анонс до наданої послуги при бажанні.'),
('241','quick_start','Быстрый запуск','Quick start','Швидкий запуск'),
('242','simple_solution','Простое решение','A simple solution','Просте рішення'),
('243','about_company','О компании','About company','Про компанію'),
('244','company_message','Наша компания является одним из лидеров в своем сегменте. Большой опыт компании и дружная команда позволяют нам предлагать свои услуги на высоком уровне.','Our company is one of the leaders in its segment. The company\'s extensive experience and friendly team allow us to offer our services at a high level. ','Наша компанія є одним з лідерів в своєму сегменті. Великий досвід компанії і дружна команда дозволяють нам пропонувати свої послуги на високому рівні. '),
('245','global_projects','Проекты','Projects','Проекти'),
('246','date','Дата','Date','Дата'),
('247','category','Категория','Category','Категорія'),
('248','site','Сайт','Site','Сайт'),
('249','customer','Клиент','Customer','Клієнт '),
('252','global_pages','Страницы','Pages','Сторінки'),
('253','global_blog','Блог','Blog','Блог'),
('254','global_articles','Статьи','Articles','Статті'),
('256','subscribe','Подписаться','Subscribe','Підписатися'),
('257','faq','FAQ','FAQ','FAQ'),
('258','account','Аккаунт','Account','Аккаунт'),
('259','author','Автор','Author','Автор');

/* Data for table t_users */
TRUNCATE TABLE `t_users`;

